TO RUN THE APPLICATION USE THE Catch-The-Dot.exe
The program files are located inside the Practical1 folder

This application is a game where the user, indicated by a blue dot, tries to catch
the computer, indicated by a red dot, both of which are drawn on the same panel. See 
the screenshot (catch-the-dot.png) for an example of the game.


-The dots are drawn on the panel by using the FillEllipse method of a Graphics object
and the size of the dots are 5 pixels.

-A timer is used to advance the position of the dots by 5 pixels every 0.1 seconds.

-The user can change the direction in which his dot moves by clicking one of four buttons
representing up, down, left and right respectively (see the screenshot).

-The direction in which the computer's dot moves is randomly change to one of the four
directions after every second (it may also continue in the same direction).

-The game starts when the user clicks a Start button. The locations of the two dots are
randomly assigned within the bounds of the panel.

-A Pause / Resume button allows the user to pause or resume the game.

-When a dot reaches the edge of the panel, it appears on the opposite side.

-The game is won when the difference in the positions of the two dots is less than 5 pixels
in both the x- and y-directions. The game stops (the dots stop moving).

-When the game is won, a message box informs the user that he had won.

-The time that had elapsed since the start of the game is displayed in a label while the
game is in progress. The time is given in seconds and is rounded to one tenth of a second.