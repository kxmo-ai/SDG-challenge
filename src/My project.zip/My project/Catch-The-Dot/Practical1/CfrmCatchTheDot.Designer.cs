﻿namespace Practical1
{
    partial class CfrmCatchTheDot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlDots = new System.Windows.Forms.Panel();
            this.lblTime = new System.Windows.Forms.Label();
            this.btnD = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnL = new System.Windows.Forms.Button();
            this.btnU = new System.Windows.Forms.Button();
            this.btnPauseResume = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.tmrDots = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // pnlDots
            // 
            this.pnlDots.BackColor = System.Drawing.Color.White;
            this.pnlDots.Location = new System.Drawing.Point(11, 12);
            this.pnlDots.Name = "pnlDots";
            this.pnlDots.Size = new System.Drawing.Size(450, 314);
            this.pnlDots.TabIndex = 1;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(402, 371);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(0, 24);
            this.lblTime.TabIndex = 14;
            // 
            // btnD
            // 
            this.btnD.Location = new System.Drawing.Point(226, 374);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(25, 23);
            this.btnD.TabIndex = 12;
            this.btnD.Text = "&D";
            this.btnD.UseVisualStyleBackColor = true;
            this.btnD.Click += new System.EventHandler(this.btnDirection_Click);
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(257, 374);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(25, 23);
            this.btnR.TabIndex = 13;
            this.btnR.Text = "&R";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnDirection_Click);
            // 
            // btnL
            // 
            this.btnL.Location = new System.Drawing.Point(195, 374);
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(25, 23);
            this.btnL.TabIndex = 11;
            this.btnL.Text = "&L";
            this.btnL.UseVisualStyleBackColor = true;
            this.btnL.Click += new System.EventHandler(this.btnDirection_Click);
            // 
            // btnU
            // 
            this.btnU.Location = new System.Drawing.Point(226, 345);
            this.btnU.Name = "btnU";
            this.btnU.Size = new System.Drawing.Size(25, 23);
            this.btnU.TabIndex = 10;
            this.btnU.Text = "&U";
            this.btnU.UseVisualStyleBackColor = true;
            this.btnU.Click += new System.EventHandler(this.btnDirection_Click);
            // 
            // btnPauseResume
            // 
            this.btnPauseResume.Enabled = false;
            this.btnPauseResume.Location = new System.Drawing.Point(11, 374);
            this.btnPauseResume.Name = "btnPauseResume";
            this.btnPauseResume.Size = new System.Drawing.Size(95, 23);
            this.btnPauseResume.TabIndex = 9;
            this.btnPauseResume.Text = "&Pause / Resume";
            this.btnPauseResume.UseVisualStyleBackColor = true;
            this.btnPauseResume.Click += new System.EventHandler(this.btnPauseResume_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(11, 345);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(94, 23);
            this.btnStart.TabIndex = 8;
            this.btnStart.Text = "&Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // tmrDots
            // 
            this.tmrDots.Tick += new System.EventHandler(this.tmrDots_Tick);
            // 
            // CfrmCatchTheDot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(471, 406);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.btnD);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnL);
            this.Controls.Add(this.btnU);
            this.Controls.Add(this.btnPauseResume);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.pnlDots);
            this.Name = "CfrmCatchTheDot";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Catch The Dot";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlDots;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.Button btnU;
        private System.Windows.Forms.Button btnPauseResume;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Timer tmrDots;
    }
}

