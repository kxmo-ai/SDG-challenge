﻿/* Student number   : 2015222637
 * Name and Surname : Kamohelo Mohlabula
 * Date             : 27 July 2017
 * Practical 1
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practical1
{
    public partial class CfrmCatchTheDot : Form
    {
        int nCounter = 0, n = 1;    //Declare and instantiate counters

        static Random r = new Random();     //Declare and instantiate random number generator

        //Declare and instantiate origin (x and y) coordinates for the blue dot and red dot
        int iBlueXOrigin = r.Next(0, 451);
        int iBlueYOrigin = r.Next(0, 316);
        int iRedXOrigin = r.Next(0, 451);
        int iRedYOrigin = r.Next(0, 316);

        //Declare and instantiate (direction) variables
        int iBlueUp = 0, iBlueRight = 0, iBlueLeft = 0, iBlueDown = 0;
        int iRedUp = 0, iRedRight = 0, iRedLeft = 0, iRedDown = 0;

        public CfrmCatchTheDot()
        {
            InitializeComponent();
        }//End CfrmCatchTheDot

        private void btnStart_Click(object sender, EventArgs e)
        {
            tmrDots.Start();
            btnPauseResume.Enabled = true;
            btnStart.Enabled = false;
        }//End btnStart

        private void btnPauseResume_Click(object sender, EventArgs e)
        {
            Graphics g = pnlDots.CreateGraphics();
            Font f = new Font("Arial", 30, FontStyle.Bold);
            SizeF s = g.MeasureString("PAUSED", f);

            n++;
            if (n % 2 == 0)
            {
                tmrDots.Stop();
                g.DrawString("PAUSED", f, Brushes.Gray, (pnlDots.Width / 2) - (s.Width / 2), (pnlDots.Height / 2) - (s.Height / 2));
            }
            else
                tmrDots.Start();
        }//End btnPauseResume

        private void btnDirection_Click(object sender, EventArgs e)
        {
            if (sender == btnU)
                iBlueUp -= 5;
            else if (sender == btnD)
                iBlueDown += 5;
            else if (sender == btnR)
                iBlueRight += 5;
            else if (sender == btnL)
                iBlueLeft -= 5;
        }//End btnDirection

        private void tmrDots_Tick(object sender, EventArgs e)
        {
            nCounter++;     //Keeps track of the number of ticks
            lblTime.Text = double.Parse((nCounter / 10.0).ToString()).ToString("0.0") + " s";   //Displays time elapsed in seconds

            Graphics g = pnlDots.CreateGraphics();      //Declare and instantiate graphics on panel
            g.Clear(Color.White);       //Clears the panel with a white background

            //Red dot coordinates (x and y) after direction is added
            int iRedX = iRedXOrigin + iRedRight + iRedLeft;
            int iRedY = iRedYOrigin + iRedUp + iRedDown;

            //Blue dot coordinates (x and y) after direction is added
            int iBlueX = iBlueXOrigin + iBlueLeft + iBlueRight;
            int iBlueY = iBlueYOrigin + iBlueUp + iBlueDown;

            int iRedXCoordinate = 0, iRedYCoordinate = 0, iBlueXCoordinate = 0, iBlueYCoordinate = 0;   //Declare and instantiate variables

            DrawGraphics(Brushes.Red, iRedX, iRedY, ref iRedXCoordinate, ref iRedYCoordinate);          //Draw red dot
            DrawGraphics(Brushes.Blue, iBlueX, iBlueY, ref iBlueXCoordinate, ref iBlueYCoordinate);     //Draw blue dot

            //Checks if the player won the game, if so the game stops and an informing message is displayed 
            if (IsWon(iRedXCoordinate, iRedYCoordinate, iBlueXCoordinate, iBlueYCoordinate))            
            {
                tmrDots.Stop();
                MessageBox.Show("You won!", "CATCH THE DOT", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);                
            }

            RedDotMovement();   //Dictates the direction (random movement) in which the computer's dot (red dot) moves 
        }//End tmrDots

        private void DrawGraphics(Brush brsh, int _iX, int _iY, ref int iXCoordinate, ref int iYCoordinate)
        {
            Graphics g = pnlDots.CreateGraphics();      //Declare and instantiate graphics on panel  

            //Makes the dot reappear on the Left(opposite) hand side, when it disappears on the Right hand side of the panel
            if (_iX > 445)
            {
                do
                    _iX -= 445;
                while (_iX > 445);

                iXCoordinate = _iX;                 //Updates coordinate within the boundaries of the panel
                g.FillEllipse(brsh, _iX, _iY, 5, 5);
            }
            //Makes the dot reappear on the Right(opposite) hand side, when it disappears on the Left hand side of the panel
            if (_iX < 0)
            {
                do
                    _iX += 445;
                while (_iX < 0);

                iXCoordinate = _iX;                 //Updates coordinate within the boundaries of the panel                 
                g.FillEllipse(brsh, _iX, _iY, 5, 5);
            }
            //Makes the dot reappear on the Upper(opposite) bound, when it disappears on the Bottom bound of the panel
            if (_iY > 310)
            {
                do
                    _iY -= 310;
                while (_iY > 310);

                iYCoordinate = _iY;                 //Updates coordinate within the boundaries of the panel
                g.FillEllipse(brsh, _iX, _iY, 5, 5);
            }
            //Makes the dot reappear on the Bottom(opposite) bound, when it disappears on the Upper bound of the panel
            if (_iY < 0)
            {
                do
                    _iY += 310;
                while (_iY < 0);

                iYCoordinate = _iY;                 //Updates coordinate within the boundaries of the panel
                g.FillEllipse(brsh, _iX, _iY, 5, 5);
            }
            else
            {
                iXCoordinate = _iX;                 //Updates coordinate within the boundaries of the panel
                iYCoordinate = _iY;                 //Updates coordinate within the boundaries of the panel
                g.FillEllipse(brsh, _iX, _iY, 5, 5);
            }
        }//End DrawGraphics
          
        private void RedDotMovement()
        {
            int iNumber = r.Next(1, 5);

            if (iNumber == 1)
                iRedUp -= 5;
            else if (iNumber == 2)
                iRedDown += 5;
            else if (iNumber == 3)
                iRedRight += 5;
            else if (iNumber == 4)
                iRedLeft -= 5;
        }//End RedDotMovement

        private bool IsWon(int _iXRed,int _iYRed, int _iXBlue, int _iYBlue)
        {
            bool isValidX = ((_iXRed - _iXBlue) >= -10 || (_iXBlue - _iXRed) <= 10) && ((_iXRed - _iXBlue) <= 10 || (_iXBlue - _iXRed) >= -10);
            bool isValidY = ((_iYRed - _iYBlue) >= -10 || (_iYBlue - _iYRed) <= 10) && ((_iYRed - _iYBlue) <= 10 || (_iYBlue - _iYRed) >= -10);
            if (isValidX && isValidY)
                return true;
            else
                return false;
        }//End IsWon
    }
}