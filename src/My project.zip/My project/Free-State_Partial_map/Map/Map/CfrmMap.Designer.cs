﻿namespace Map
{
    partial class CfrmMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNeighbours = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNeighbours
            // 
            this.btnNeighbours.Location = new System.Drawing.Point(212, 21);
            this.btnNeighbours.Name = "btnNeighbours";
            this.btnNeighbours.Size = new System.Drawing.Size(108, 23);
            this.btnNeighbours.TabIndex = 0;
            this.btnNeighbours.Text = "Neighbours of ...";
            this.btnNeighbours.UseVisualStyleBackColor = true;
            this.btnNeighbours.Click += new System.EventHandler(this.btnNeighbours_Click);
            // 
            // CfrmMap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1060, 623);
            this.Controls.Add(this.btnNeighbours);
            this.Name = "CfrmMap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Map of Free State";
            this.Load += new System.EventHandler(this.CfrmMap_Load);
            this.Shown += new System.EventHandler(this.CfrmMap_Shown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNeighbours;
    }
}

