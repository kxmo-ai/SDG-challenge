﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Map
{
    public partial class CfrmMap : Form
    {
        public CfrmMap()
        {
            InitializeComponent();
        }

        private Graph mapFS;

        private void CfrmMap_Load(object sender, EventArgs e)
        {
            //Add vertices
            Vertex vBloemfontein = new Vertex("Bloemfontein", new Point(100, 500));
            Vertex vBrandfort = new Vertex("Brandfort", new Point(200, 300));
            Vertex vBultfontein = new Vertex("Bultfontein", new Point(50, 100));
            Vertex vTheunissen = new Vertex("Theunissen", new Point(300, 120));
            Vertex vWinburg = new Vertex("Winburg", new Point(500, 150));
            Vertex vBotshabelo = new Vertex("Botshabelo", new Point(420, 550));
            Vertex vExcelsior = new Vertex("Excelsior", new Point(550, 430));
            Vertex vTweespruit = new Vertex("Tweespruit", new Point(530, 540));
            Vertex vLadybrand = new Vertex("Ladybrand", new Point(700, 540));
            Vertex vMaseru = new Vertex("Maseru", new Point(720, 580));
            Vertex vClocolan = new Vertex("Clocolan", new Point(730, 420));
            Vertex vMarquard = new Vertex("Marquard", new Point(660, 270));
            Vertex vFicksburg = new Vertex("Ficksburg", new Point(850, 400));
            Vertex vSenekal = new Vertex("Senekal", new Point(700, 100));
            Vertex vVentersburg = new Vertex("Ventersburg", new Point(600, 20));
            Vertex vBethlehem = new Vertex("Bethlehem", new Point(950, 80));
            Vertex vFouriesburg = new Vertex("Fouriesburg", new Point(930, 250));
           
            //Add children
            vBloemfontein.AddChildren(new Vertex[] { vBrandfort, vBultfontein, vWinburg, vBotshabelo });
            vWinburg.AddChildren(new Vertex[] { vSenekal, vVentersburg });
            vBultfontein.AddChildren(new Vertex[] { vTheunissen });
            vBrandfort.AddChildren(new Vertex[] { vTheunissen, vExcelsior });
            vTheunissen.AddChildren(new Vertex[] { vWinburg });
            vBotshabelo.AddChildren(new Vertex[] { vTweespruit });
            vTweespruit.AddChildren(new Vertex[] { vExcelsior, vLadybrand });
            vLadybrand.AddChildren(new Vertex[] { vMaseru, vClocolan });
            vExcelsior.AddChildren(new Vertex[] { vClocolan, vWinburg });
            vClocolan.AddChildren(new Vertex[] { vMarquard, vFicksburg });
            vFicksburg.AddChildren(new Vertex[] { vSenekal, vFouriesburg });
            vSenekal.AddChildren(new Vertex[] { vBethlehem });
            vMarquard.AddChildren(new Vertex[] { vWinburg, vSenekal });
            vVentersburg.AddChildren(new Vertex[] { vSenekal });
            vFouriesburg.AddChildren(new Vertex[] { vBethlehem });
            
            //Create graph
            mapFS = new Graph(vBloemfontein);
        } //Load

        private void btnNeighbours_Click(object sender, EventArgs e)
        {
            GetNeighbours();
        }

        private void CfrmMap_Shown(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Draw(g);
        }

        private void Draw(Graphics g)
        {
            Point mid;

            //Draw town locations and print town names
            foreach (Vertex v in mapFS.LstVertices)
            {
                g.FillEllipse(Brushes.Black, (float)(v.Location.X - 3.5), (float)(v.Location.Y - 3.5), 7, 7);   //Draw places
                g.DrawString(v.Label, DefaultFont, Brushes.Black, v.Location.X + 1, v.Location.Y + 1);          //Draw name of places
                
                if (v.Children.Count > 0)
                {
                    for (int i = 0; i < v.Children.Count; i++)
                    {
                        //Draws the route from A to B and vice-versa
                        g.DrawLine(Pens.Black, v.Location.X, v.Location.Y,
                                   v.Children[i].Location.X, v.Children[i].Location.Y);

                        //MidPoint (x,y) between the distance AB
                        mid = new Point(
                                         (int)(Math.Sqrt(Math.Pow(v.Location.X + v.Children[i].Location.X, 2)) / 2),    // x-coordinate of MidpPoint = Math.Sqrt[ (x2 + x1)^2 ] / 2
                                         (int)(Math.Sqrt(Math.Pow(v.Location.Y + v.Children[i].Location.Y, 2)) / 2)     // y-coordinate of MidpPoint = Math.Sqrt[ (y2 + y1)^2 ] / 2
                                        );
                        
                        //Draws the length of the distance between two points A and B
                        g.DrawString(decimal.Round((decimal)GetDistance(v, v.Children[i])).ToString()
                                     , DefaultFont, Brushes.Blue, mid);                        
                    }//for
                }//if
            }
        }//Draw

        private double GetDistance(Vertex v1, Vertex v2)
        {
            //Implementing the Distance Formula  Math.Sqrt[ (x2 - x1)^2 + (y2 - y1)^2 ] / 5
            return Math.Sqrt( Math.Pow(v2.Location.X - v1.Location.X, 2) +
                              Math.Pow(v2.Location.Y - v1.Location.Y, 2)) / 5; 
        }//GetDistance

        private void GetNeighbours()
        {
            string sMsg = "";
            string sTown = Microsoft.VisualBasic.Interaction.InputBox("Neighbours of ...", "Get neigbours");

            if (mapFS.LstVertices.Contains(mapFS.FindVertex(sTown)))
            {
                for (int i = 0; i < mapFS.LstVertices.Count; i++)
                {
                    if (mapFS.LstVertices[i].Label != sTown && mapFS.LstVertices[i].Children.Contains(mapFS.FindVertex(sTown)))
                        sMsg += mapFS.LstVertices[i].Label + "\t\t" + 
                                GetDistance(mapFS.FindVertex(sTown), mapFS.LstVertices[i]).ToString("#.0") + "\n";

                    if (mapFS.LstVertices[i].Label == sTown)
                        for (int j = 0; j < mapFS.LstVertices[i].Children.Count; j++)
                            sMsg += mapFS.LstVertices[i].Children[j].Label + "\t\t" +
                                GetDistance(mapFS.FindVertex(sTown), mapFS.LstVertices[i].Children[j]).ToString("#.0") + "\n";
                }

                MessageBox.Show(sMsg, "Neighbours of " + sTown);
            }

        }//GetNeighours
    }
}
