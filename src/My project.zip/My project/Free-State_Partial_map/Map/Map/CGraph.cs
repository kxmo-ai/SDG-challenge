﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Map
{
    public class Graph
    {
        private List<Vertex> lstVertices;

        #region Constructors
        public Graph()
        {

        }

        public Graph(Vertex vertex)
        {
            lstVertices = new List<Vertex>();
            DFS(vertex);
            LstVertices = lstVertices;
        }//Constructor
        #endregion

        public List<Vertex> LstVertices { get; private set; }

        #region Methods
        public Vertex FindVertex(string Label)
        {
            bool isFound = false;
            int i = 0;
            while (i < lstVertices.Count && !isFound)
            {
                if (lstVertices[i].Label == Label)
                    isFound = true;
                else
                    i++;
            } //while

            return isFound ? lstVertices[i] : null;
        }//FindVertex

        private void DFS(Vertex vertex)
        {
            if (!lstVertices.Contains(vertex))
                lstVertices.Add(vertex);

            foreach (Vertex v in vertex.Children)
            {
                if (!lstVertices.Contains(v))
                lstVertices.Add(v);

                if (v.Children.Count > 0)
                    DFS(v);
            }
        }//DFS
        #endregion
    }


}
