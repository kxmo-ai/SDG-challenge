﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Map
{
    public class Vertex
    {
        #region Constructors
        public Vertex()
        {

        }

        public Vertex(string sLabel, Point pLocation)
        {
            Label = sLabel;
            Location = pLocation;
            Children = new List<Vertex>();
        }//Constructor
        #endregion

        #region Properties
        public string Label { get; private set; }

        public Point Location{ get; private set; }

        public List<Vertex> Children { get; private set; }
        #endregion

        #region Methods
        public void AddChildren(Vertex[] vertex)
        {
            foreach (Vertex v in vertex)
                if (Children.IndexOf(v) < 0)
                    Children.Add(v);
        }//Add Children    
        #endregion
    }
}
