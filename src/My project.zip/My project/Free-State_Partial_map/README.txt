TO RUN THE APPLICATION USE THE Map.exe
The program files are located inside the Map folder

This project imitates a partial map of the Free State, similar to the image (map.png) provided.
It uses a list of vertices graph implementation to draw the schematic map. It gets the neighbours
of the town provided from the user input given the town is on the scale of the map.

I have two classes, one of type vertex and another of type graph. The vertex class is basically 
used to create the necessary towns and assigns properties to them. Where the graph class stores 
and uses these vertices to create a map on the form.

The vertex class properties and/or methods:
-Label for a town's name
-Location (as a point in pixel coordinates)
-List of children (immediate neighbouring towns)
-It also has an AddChildren method to add children of the given vertex.

The graph class properties:
-A start vertex
-A read-only list of all vertices.
-It also has a FindVertex method that finds a specific town based on its label.

When the form loads the map is drawn with a scaled pixel distance divide by 5 to get more or less a
kilometer distance.

When the program runs the user can use the "neigbours of..." button to get the neighbours of the desired town.

